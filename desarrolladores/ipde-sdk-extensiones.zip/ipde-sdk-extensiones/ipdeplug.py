# -*- coding: utf-8 -*-
"""SDK de extensiones de la plataforma: crear, probar, firmar, empaquetar, verificar y distribuir paquetes .ipdeplug.

Produce exactamente los mismos paquetes que `consola firmar` de la edición Lite (consola/src/firma.rs): la consola,
el panel Extensiones del geoportal y este programa verifican igual.

    python ipdeplug.py crear ID [--plantilla pagina|capas] [--nombre "…"] [--editor ID] [--carpeta DIR]
        crea un proyecto: abra la carpeta en su editor (VS Code); lo que se firma va en su subcarpeta paquete/
    python ipdeplug.py validar CARPETA
    python ipdeplug.py probar CARPETA                   banco de pruebas en el navegador, sin firmar
    python ipdeplug.py editor-solicitar --id ID --nombre "…" [--correo …] [-o DIR]
    python ipdeplug.py editor-emitir SOLICITUD --raiz DIR [--anios 2] [-o DIR]      (sólo la autoridad de la plataforma)
    python ipdeplug.py empaquetar CARPETA --editor DIR [-o SALIDA.ipdeplug]
    python ipdeplug.py verificar PAQUETE|CARPETA [--raiz-publica ARCHIVO]
    python ipdeplug.py ficha PAQUETE [--archivo NOMBRE] [-o ficha.json]              entrada para el catálogo

CARPETA puede ser el proyecto (con paquete/ dentro) o directamente la carpeta que lleva extension.toml.
Requiere Python 3.9 o posterior y el paquete `cryptography` (pip install cryptography).

Licencia del SDK: MIT. Lo que genera (plantillas, puente, AGENTS.md) es suyo y puede usarlo en extensiones de
cualquier licencia, también comerciales.
"""
import argparse
import base64
import datetime
import hashlib
import html
import json
import os
import pathlib
import re
import shutil
import sys
import tempfile
import webbrowser
import zipfile

VERSION_SDK = '1.1.0'
AQUI = pathlib.Path(__file__).resolve().parent
META, HASHES, CERT, FIRMA, MANIFIESTO = 'META', 'META/hashes.json', 'META/publisher.cert.json', 'META/signature.json', 'extension.toml'
PAQUETE = 'paquete'   # dentro del proyecto: lo único que se firma
ID_VALIDO = re.compile(r'^[A-Za-z0-9_-]{1,64}$')
VERSION_VALIDA = re.compile(r'^\d+\.\d+\.\d+([-+][0-9A-Za-z.-]+)?$')
PERMISOS = {'mapa.ir': 'centrar el mapa en un punto', 'capas.leer': 'leer la lista y los datos de las capas',
            'capas.agregar': 'añadir una capa al mapa', 'descargas': 'guardar un archivo en el equipo'}
MODOS = {'catalogo': 'en el catálogo de extensiones de la plataforma',
         'independiente': 'por su cuenta (su sitio, su tienda, su contrato), fuera del catálogo',
         'privada': 'sólo para su organización; no se anuncia'}
PRECIOS = ('gratuita', 'pago', 'suscripcion', 'consultar')
LIMITE_MB = 50   # lo que acepta el panel Extensiones del geoportal


class Error(Exception):
    pass


def _cripto():
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.exceptions import InvalidSignature
    except ImportError:
        raise Error('falta el paquete «cryptography»: pip install cryptography')
    return hashes, serialization, ec, InvalidSignature


def hoy():
    return datetime.date.today().isoformat()


# ---------- claves y firmas: ECDSA P-256 + SHA-256, firmas DER y claves públicas SPKI DER, todo en base64 ----------

def nueva_clave():
    _, _, ec, _ = _cripto()
    return ec.generate_private_key(ec.SECP256R1())


def clave_pem(clave):
    _, serialization, _, _ = _cripto()
    return clave.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())


def leer_clave(ruta):
    _, serialization, _, _ = _cripto()
    try:
        return serialization.load_pem_private_key(pathlib.Path(ruta).read_bytes(), password=None)
    except FileNotFoundError:
        raise Error(f'no existe {ruta}')
    except (ValueError, TypeError) as e:
        raise Error(f'clave privada ilegible ({ruta}): {e}')


def publica_b64(clave):
    _, serialization, _, _ = _cripto()
    return base64.b64encode(clave.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)).decode()


def firmar_bytes(clave, datos):
    hashes, _, ec, _ = _cripto()
    return base64.b64encode(clave.sign(datos, ec.ECDSA(hashes.SHA256()))).decode()


def verifica(pub_b64, datos, firma_b64):
    hashes, serialization, ec, InvalidSignature = _cripto()
    try:
        k = serialization.load_der_public_key(base64.b64decode(pub_b64.strip()))
        k.verify(base64.b64decode(firma_b64.strip()), datos, ec.ECDSA(hashes.SHA256()))
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False


def carga_util_cert(c):
    return '\n'.join([c['publisher_id'], c['name'], c['pubkey'], c['issued'], c['expires']]).encode('utf-8')


def carga_util_solicitud(s):
    return '\n'.join(['ipde-solicitud-editor', s['publisher_id'], s['name'], s['pubkey'], s['fecha']]).encode('utf-8')


def raiz_publica(ruta=None):
    for p in [ruta] if ruta else [AQUI / 'raiz_publica.txt', AQUI.parent / 'consola' / 'firma' / 'raiz_publica.txt']:
        if p and pathlib.Path(p).is_file():
            return pathlib.Path(p).read_text(encoding='utf-8').strip()
    raise Error('no se encuentra raiz_publica.txt (la clave pública de la plataforma)')


# ---------- manifiesto ----------

def carpeta_paquete(ruta):
    """El proyecto que crea `crear` lleva el paquete en paquete/; también vale la carpeta del paquete misma."""
    r = pathlib.Path(ruta)
    if (r / MANIFIESTO).is_file():
        return r
    if (r / PAQUETE / MANIFIESTO).is_file():
        return r / PAQUETE
    raise Error(f'no hay {MANIFIESTO} en {r} ni en {r / PAQUETE}')


def leer_manifiesto(carpeta):
    p = pathlib.Path(carpeta) / MANIFIESTO
    if not p.is_file():
        raise Error(f'falta {MANIFIESTO} en {carpeta}')
    try:
        import tomllib
    except ImportError:   # Python < 3.11
        try:
            import tomli as tomllib
        except ImportError:
            raise Error('Python 3.11 o posterior (o pip install tomli) para leer extension.toml')
    try:
        return tomllib.loads(p.read_text(encoding='utf-8'))
    except Exception as e:
        raise Error(f'{MANIFIESTO} inválido: {e}')


def revisar_manifiesto(m, carpeta):
    """Errores (impiden firmar) y avisos. Las mismas reglas que la consola y el geoportal, más las de distribución."""
    err, av = [], []
    for k in ('id', 'nombre', 'version'):
        if not isinstance(m.get(k), str) or not m[k].strip():
            err.append(f'falta «{k}»')
    if isinstance(m.get('id'), str) and not ID_VALIDO.match(m['id']):
        err.append('«id» sólo admite letras, números, - y _ (hasta 64)')
    if isinstance(m.get('version'), str) and not VERSION_VALIDA.match(m['version']):
        err.append('«version» debe ser X.Y.Z (p. ej. 1.0.0)')
    if m.get('nivel', 'opcional') not in ('opcional', 'nucleo'):
        err.append('«nivel» es "opcional" o "nucleo"')
    if m.get('nivel') == 'nucleo':
        av.append('nivel "nucleo": el administrador no podrá deshabilitarla desde la web; para extensiones de terceros use "opcional"')
    for k in m.get('permisos', []):
        if k not in PERMISOS:
            err.append(f'permiso desconocido «{k}» (válidos: {", ".join(PERMISOS)})')
    acciones = {k: m.get(k, []) for k in ('instalar', 'habilitar', 'deshabilitar', 'desinstalar')}
    for fase, pasos in acciones.items():
        for p in pasos:
            a = p.get('accion')
            if a not in ('copiar', 'borrar', 'sql', 'mensaje', 'orden'):
                err.append(f'[[{fase}]]: acción desconocida «{a}»')
            if a == 'orden':
                av.append(f'[[{fase}]] usa «orden»: la consola la rechaza salvo que el administrador active permitir_ordenes; evítela')
            if a == 'sql':
                av.append(f'[[{fase}]] ejecuta SQL con todos los permisos sobre la base: el administrador lo revisará antes de instalar')
            for clave in ('desde', 'hacia', 'ruta', 'archivo'):
                v = p.get(clave)
                if isinstance(v, str) and (v.startswith(('/', '\\')) or re.match(r'^[A-Za-z]:', v) or '..' in re.split(r'[\\/]', v)):
                    err.append(f'[[{fase}]] {clave} = "{v}": no se admiten rutas absolutas ni ..')
            for clave in ('desde', 'archivo'):
                v = p.get(clave)
                if isinstance(v, str) and not (pathlib.Path(carpeta) / v).exists():
                    err.append(f'[[{fase}]] {clave} = "{v}": no existe en la carpeta')
    pag = next((p for p in acciones['habilitar'] if p.get('accion') == 'copiar'), None)
    if pag is None:
        av.append('sin [[habilitar]] copiar: la extensión no publica ninguna página en la interfaz')
    elif not (pathlib.Path(carpeta) / pag['desde'] / 'index.html').is_file():
        err.append(f'[[habilitar]] copia «{pag["desde"]}» pero no hay {pag["desde"]}/index.html')
    elif pag.get('hacia') != '{interfaz}/extensiones/' + str(m.get('id')):
        av.append(f'[[habilitar]] hacia = "{pag.get("hacia")}": la convención es "{{interfaz}}/extensiones/{m.get("id")}"')
    d = m.get('distribucion')
    if not isinstance(d, dict):
        err.append('falta la tabla [distribucion] (modo, licencia y url: dónde se adquiere)')
    else:
        modo = d.get('modo')
        if modo not in MODOS:
            err.append(f'[distribucion] modo = "{modo}": use {", ".join(MODOS)}')
        if not str(d.get('licencia', '')).strip():
            err.append('[distribucion] falta «licencia» (p. ej. "MIT", "Apache-2.0" o "Propietaria")')
        if d.get('precio', 'gratuita') not in PRECIOS:
            err.append(f'[distribucion] precio = "{d.get("precio")}": use {", ".join(PRECIOS)}')
        url = str(d.get('url', '')).strip()
        if modo in ('catalogo', 'independiente') and not url:
            err.append('[distribucion] falta «url»: la dirección donde los usuarios pueden adquirirla o descargarla')
        if url and not re.match(r'^https://[^\s/]+\.[^\s]+$', url):
            err.append('[distribucion] «url» debe empezar con https://')
        if d.get('soporte') and not re.match(r'^(https://\S+|[^@\s]+@[^@\s]+\.\S+)$', str(d['soporte'])):
            err.append('[distribucion] «soporte» es un correo o una dirección https://')
    return err, av


# ---------- carga útil, firma y paquete (idéntico a firma.rs) ----------

def archivos_carga(carpeta):
    base = pathlib.Path(carpeta)
    out = []
    for raiz, dirs, archivos in os.walk(base):
        rel_raiz = pathlib.Path(raiz).relative_to(base)
        if rel_raiz == pathlib.Path('.'):
            dirs[:] = [d for d in dirs if d != META]
        for d in dirs:
            if (pathlib.Path(raiz) / d).is_symlink():
                raise Error(f'tipo de archivo no admitido (enlace): {(rel_raiz / d).as_posix()}')
        for a in archivos:
            p = pathlib.Path(raiz) / a
            if p.is_symlink():
                raise Error(f'tipo de archivo no admitido (enlace): {(rel_raiz / a).as_posix()}')
            out.append((rel_raiz / a).as_posix())
    return sorted(out)


def sha256(ruta):
    h = hashlib.sha256()
    with open(ruta, 'rb') as f:
        for b in iter(lambda: f.read(65536), b''):
            h.update(b)
    return h.hexdigest()


def cargar_editor(dir_editor):
    d = pathlib.Path(dir_editor)
    clave = leer_clave(d / 'publisher_private.pem')
    try:
        cert = json.loads((d / 'publisher.cert.json').read_text(encoding='utf-8'))
    except FileNotFoundError:
        raise Error(f'falta publisher.cert.json en {d}: la plataforma se lo entrega al aprobar su solicitud')
    if publica_b64(clave) != cert.get('pubkey'):
        raise Error('la clave privada no corresponde al certificado de ese editor')
    return clave, cert


def firmar_carpeta(carpeta, clave, cert):
    carpeta = pathlib.Path(carpeta)
    m = leer_manifiesto(carpeta)
    err, av = revisar_manifiesto(m, carpeta)
    if m.get('editor') and m['editor'] != cert['publisher_id']:
        err.append(f'extension.toml declara editor «{m["editor"]}» pero el certificado es de «{cert["publisher_id"]}»')
    if cert.get('expires', '') < hoy():
        err.append(f'su certificado de editor venció el {cert.get("expires")}: pida uno nuevo a la plataforma')
    if not verifica(raiz_publica(), carga_util_cert(cert), cert.get('root_sig', '')):
        av.append('el certificado no está firmado por la raíz de esta plataforma: el paquete no se instalará en ella')
    if err:
        raise Error('no se firma:\n  - ' + '\n  - '.join(err))
    sobra = [r for r in archivos_carga(carpeta) if re.search(r'(^|/)(\.git|__pycache__|node_modules|\.DS_Store|Thumbs\.db)(/|$)', r)]
    if sobra:
        raise Error('la carpeta lleva archivos que no deben ir en el paquete: ' + ', '.join(sobra[:5]) + ('…' if len(sobra) > 5 else ''))
    meta = carpeta / META
    if meta.exists():
        shutil.rmtree(meta)
    meta.mkdir()
    archivos = archivos_carga(carpeta)
    hashes_bytes = json.dumps({'alg': 'SHA-256', 'files': {r: sha256(carpeta / r) for r in archivos}}, indent=2, sort_keys=True, ensure_ascii=False).encode('utf-8')
    (carpeta / HASHES).write_bytes(hashes_bytes)
    (carpeta / CERT).write_text(json.dumps(cert, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    firma = {'alg': 'SHA256withECDSA', 'publisher_id': cert['publisher_id'], 'plugin_id': m['id'], 'version': m['version'], 'signed_at': hoy(), 'sig': firmar_bytes(clave, hashes_bytes)}
    (carpeta / FIRMA).write_text(json.dumps(firma, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    return m, archivos, av


def empaquetar_carpeta(carpeta, id_, salida):
    carpeta = pathlib.Path(carpeta)
    with zipfile.ZipFile(salida, 'w', zipfile.ZIP_DEFLATED) as z:
        for rel in archivos_carga(carpeta) + [CERT, HASHES, FIRMA]:
            z.write(carpeta / rel, f'{id_}/{rel}')


def extraer(paquete, destino):
    destino = pathlib.Path(destino).resolve()
    try:
        z = zipfile.ZipFile(paquete)
    except zipfile.BadZipFile:
        raise Error('no es un paquete zip válido')
    total = 0
    with z:
        for i in z.infolist():
            n = i.filename
            if n.startswith(('/', '\\')) or '\\' in n or re.match(r'^[A-Za-z]:', n) or '..' in n.split('/'):
                raise Error(f'entrada de ZIP inválida: {n}')
            total += i.file_size
            if total > LIMITE_MB * 1024 * 1024:
                raise Error(f'el paquete descomprimido supera {LIMITE_MB} MB')
        z.extractall(destino)
    if (destino / MANIFIESTO).is_file():
        return destino
    hijos = list(destino.iterdir())
    if len(hijos) == 1 and (hijos[0] / MANIFIESTO).is_file():
        return hijos[0]
    raise Error(f'el paquete no contiene {MANIFIESTO}')


def verificar_carpeta(carpeta, raiz_b64, fecha=None):
    carpeta = pathlib.Path(carpeta)
    fecha = fecha or hoy()
    for req in (HASHES, CERT, FIRMA):
        if not (carpeta / req).is_file():
            raise Error(f'SIN FIRMAR: falta {req}')
    try:
        cert = json.loads((carpeta / CERT).read_text(encoding='utf-8'))
        firma = json.loads((carpeta / FIRMA).read_text(encoding='utf-8'))
        hashes_bytes = (carpeta / HASHES).read_bytes()
        hashes = json.loads(hashes_bytes)
    except (ValueError, OSError) as e:
        raise Error(f'META ilegible: {e}')
    m = leer_manifiesto(carpeta)
    if not verifica(raiz_b64, carga_util_cert(cert), cert.get('root_sig', '')):
        raise Error('INVÁLIDO: el certificado del editor no está firmado por la raíz de esta plataforma.')
    if cert['expires'] < fecha:
        raise Error(f'INVÁLIDO: el certificado del editor venció el {cert["expires"]}.')
    if not verifica(cert['pubkey'], hashes_bytes, firma.get('sig', '')):
        raise Error('INVÁLIDO: la firma del paquete no valida con la clave del editor.')
    if firma.get('publisher_id') != cert['publisher_id']:
        raise Error('INVÁLIDO: publisher_id de la firma ≠ certificado.')
    if m.get('editor') is not None and m['editor'] != cert['publisher_id']:
        raise Error('INVÁLIDO: el manifiesto declara otro editor.')
    if m.get('id') != firma.get('plugin_id'):
        raise Error('INVÁLIDO: id del manifiesto ≠ firma.')
    if m.get('version') != firma.get('version'):
        raise Error('INVÁLIDO: versión del manifiesto ≠ firma.')
    if hashes.get('alg') != 'SHA-256':
        raise Error('INVÁLIDO: algoritmo de hash no admitido.')
    decl, reales = hashes.get('files', {}), archivos_carga(carpeta)
    for f in decl:
        if f not in reales:
            raise Error(f'INVÁLIDO: falta un archivo declarado: {f}')
    for f in reales:
        if f not in decl:
            raise Error(f'INVÁLIDO: archivo no declarado en la firma: {f}')
    for rel, h in decl.items():
        if sha256(carpeta / rel) != h:
            raise Error(f'INVÁLIDO: «{rel}» fue modificado después de firmar.')
    return m, cert, len(decl)


def verificar(ruta, raiz_b64):
    ruta = pathlib.Path(ruta)
    if ruta.is_dir():
        return verificar_carpeta(carpeta_paquete(ruta), raiz_b64)
    with tempfile.TemporaryDirectory(prefix='ipdeplug-') as t:
        return verificar_carpeta(extraer(ruta, t), raiz_b64)


# ---------- plantillas ----------

def _manifiesto_nuevo(id_, nombre, editor, plantilla):
    permisos = '["mapa.ir"]' if plantilla == 'pagina' else '["mapa.ir", "capas.leer", "capas.agregar", "descargas"]'
    return f'''# Manifiesto de la extensión. La plataforma lo verifica con la firma: lo que no esté aquí no se le concede.
id = "{id_}"
nombre = "{nombre}"
version = "1.0.0"
descripcion = "Qué hace, en una frase."
{'editor = "' + editor + '"' if editor else '# editor = "su_id_de_editor"      # opcional; si lo pone, debe ser el de su certificado'}
nivel = "opcional"
requiere = []
# Lo único que la interfaz atiende de su página: mapa.ir, capas.leer, capas.agregar, descargas
permisos = {permisos}

# Cómo se distribuye. El código y los derechos son de usted: la plataforma sólo verifica la firma
# y, si elige «catalogo», la anuncia en su catálogo con este enlace.
[distribucion]
modo = "independiente"          # catalogo | independiente | privada
licencia = "Propietaria"        # o MIT, Apache-2.0, GPL-3.0-or-later, EUPL-1.2…
precio = "gratuita"             # gratuita | pago | suscripcion | consultar
url = "https://example.com/{id_}"    # dónde los usuarios la adquieren o descargan (obligatoria salvo «privada»)
# soporte = "soporte@example.com"

[[instalar]]
accion = "mensaje"
texto = "Instalando {nombre}"

[[habilitar]]
accion = "copiar"
desde = "web"
hacia = "{{interfaz}}/extensiones/{id_}"

[[deshabilitar]]
accion = "borrar"
ruta = "{{interfaz}}/extensiones/{id_}"

[[desinstalar]]
accion = "mensaje"
texto = "{nombre} retirada"
'''


_ESTILO = ''':root{color-scheme:light dark;--b:#d0d7de;--t:#1f2328;--m:#59636e;--a:#0b7285;--bg:#fff}
@media (prefers-color-scheme:dark){:root{--b:#3d444d;--t:#e6edf3;--m:#9198a1;--a:#3bc9db;--bg:#0d1117}}
body{font:13px/1.45 system-ui,sans-serif;margin:0;padding:12px;color:var(--t);background:var(--bg)}
h1{font-size:15px;margin:0 0 8px}
label{display:block;font-size:12px;color:var(--m);margin:8px 0 2px}
input,select{width:100%;box-sizing:border-box;padding:6px 8px;border:1px solid var(--b);border-radius:6px;background:transparent;color:inherit;font:inherit}
button{margin:8px 6px 0 0;padding:6px 10px;border:1px solid var(--a);border-radius:6px;background:var(--a);color:#fff;font:inherit;cursor:pointer}
button.sec{background:transparent;color:var(--a)}
.res{font-family:ui-monospace,Consolas,monospace;font-size:12px;margin-top:8px;white-space:pre-wrap;word-break:break-word}
.err{color:#cf222e}'''

# Cliente del puente: cada pedido lleva un número y la interfaz contesta con el mismo número.
_PUENTE = '''// ---- Puente con el geoportal: la página vive en un marco aislado y sólo habla por mensajes ----
let siguiente = 1;
const esperando = new Map();
addEventListener('message', e => {
  const d = e.data;
  if (!d || typeof d.tipo !== 'string') return;
  if (d.pedido && esperando.has(d.pedido)) {
    const {ok, mal} = esperando.get(d.pedido); esperando.delete(d.pedido);
    d.tipo === 'ipde.error' ? mal(new Error(d.error)) : ok(d);
  }
});
function pedir(tipo, datos = {}, ms = 30000) {
  const pedido = 'p' + siguiente++;
  return new Promise((ok, mal) => {
    esperando.set(pedido, {ok, mal});
    parent.postMessage(Object.assign({tipo, pedido}, datos), '*');
    setTimeout(() => { if (esperando.delete(pedido)) mal(new Error('el geoportal no respondió')); }, ms);
  });
}
const ipde = {
  ir: (lon, lat, zoom) => parent.postMessage({tipo: 'ipde.ir', lon, lat, zoom}, '*'),          // mapa.ir (sin respuesta)
  capas: () => pedir('ipde.capas?').then(r => r.capas),                                        // capas.leer
  datos: id => pedir('ipde.datos?', {id}).then(r => r.fc),                                     // capas.leer: GeoJSON en WGS 84
  agregarCapa: (titulo, fc) => pedir('ipde.capa', {titulo, fc}),                               // capas.agregar
  descargar: (nombre, texto, tipoMime) => pedir('ipde.descargar', {nombre, texto, tipoMime}),  // descargas
  ampliar: grande => parent.postMessage({tipo: 'ipde.tamano', grande}, '*')
};'''


def _pagina_nueva(nombre, plantilla):
    if plantilla == 'pagina':
        cuerpo = '''<h1>''' + html.escape(nombre) + '''</h1>
<p>Escriba unas coordenadas y la extensión centra el mapa del geoportal en ese punto.</p>
<label for="lat">Latitud</label><input id="lat" inputmode="decimal" value="8.9824">
<label for="lon">Longitud</label><input id="lon" inputmode="decimal" value="-79.5199">
<button id="ir" type="button">Ver en el mapa</button>
<div id="res" class="res" role="status"></div>'''
        logica = '''const $ = id => document.getElementById(id), num = id => Number(String($(id).value).replace(',', '.'));
$('ir').onclick = () => {
  const lat = num('lat'), lon = num('lon');
  if (!(Math.abs(lat) <= 85 && Math.abs(lon) <= 180)) { $('res').innerHTML = '<span class="err">Coordenadas fuera de rango</span>'; return; }
  ipde.ir(lon, lat, 14); $('res').textContent = 'Mapa centrado en ' + lat + ', ' + lon;
};'''
    else:
        cuerpo = '''<h1>''' + html.escape(nombre) + '''</h1>
<p>Lee una capa del geoportal, calcula sus centroides, los añade al mapa como capa nueva y los guarda en CSV.</p>
<label for="capa">Capa</label><select id="capa"><option value="">Cargando…</option></select>
<button id="calc" type="button">Calcular centroides</button><button id="csv" class="sec" type="button" disabled>Descargar CSV</button>
<div id="res" class="res" role="status"></div>'''
        logica = '''const $ = id => document.getElementById(id);
let ultimo = null;
// centroide aproximado: promedio de los vértices (suficiente para el ejemplo)
function centroide(g) {
  const pts = [];
  (function rec(c) { if (typeof c[0] === 'number') pts.push(c); else c.forEach(rec); })(g.type === 'GeometryCollection' ? g.geometries.map(x => x.coordinates) : g.coordinates);
  return pts.length ? [pts.reduce((s, p) => s + p[0], 0) / pts.length, pts.reduce((s, p) => s + p[1], 0) / pts.length] : null;
}
ipde.capas().then(l => {
  $('capa').innerHTML = l.map(c => `<option value="${c.id}">${c.titulo.replace(/</g, '&lt;')} (${c.geometria || '?'})</option>`).join('') || '<option value="">No hay capas con datos</option>';
}, e => { $('res').innerHTML = '<span class="err">' + e.message + '</span>'; });
$('calc').onclick = async () => {
  const id = $('capa').value; if (!id) return;
  $('res').textContent = 'Leyendo…';
  try {
    const fc = await ipde.datos(id);
    const puntos = fc.features.map((f, i) => { const c = centroide(f.geometry); return c && {type: 'Feature', properties: Object.assign({n: i + 1}, f.properties), geometry: {type: 'Point', coordinates: c}}; }).filter(Boolean);
    ultimo = puntos;
    const r = await ipde.agregarCapa('Centroides de ' + $('capa').selectedOptions[0].text, {type: 'FeatureCollection', features: puntos});
    $('res').textContent = r.elementos + ' centroides añadidos al mapa'; $('csv').disabled = false;
    if (puntos[0]) ipde.ir(puntos[0].geometry.coordinates[0], puntos[0].geometry.coordinates[1]);
  } catch (e) { $('res').innerHTML = '<span class="err">' + e.message + '</span>'; }
};
$('csv').onclick = () => {
  const filas = ['n,lon,lat', ...ultimo.map(f => [f.properties.n, ...f.geometry.coordinates.map(v => v.toFixed(6))].join(','))];
  ipde.descargar('centroides.csv', filas.join('\\n'), 'text/csv').catch(e => { $('res').innerHTML = '<span class="err">' + e.message + '</span>'; });
};'''
    return f'''<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(nombre)}</title>
<!-- Una sola página autocontenida: en el geoportal se abre en un marco aislado (sandbox="allow-scripts"),
     sin acceso a sus otros archivos, a cookies ni a localStorage. Bibliotecas: en línea o desde un CDN con CORS. -->
<style>
{_ESTILO}
</style></head>
<body>
{cuerpo}
<script>
{_PUENTE}

{logica}
</script>
</body></html>
'''


def _leeme_nuevo(id_, nombre):
    return f'''# {nombre}

Extensión para el geoportal (paquete `.ipdeplug`).

```
{id_}/                  abra esta carpeta en su editor (VS Code)
  AGENTS.md             reglas del puente para asistentes de IA (CLAUDE.md la importa)
  paquete/              lo único que se firma y se distribuye
    extension.toml      manifiesto: permisos y [distribucion]
    web/index.html      la página de la extensión (un solo archivo)
```

- Probar sin firmar: `python ipdeplug.py probar .`
- Revisar el manifiesto: `python ipdeplug.py validar .`
- Firmar y empaquetar: `python ipdeplug.py empaquetar . --editor RUTA_A_SU_CARPETA_DE_EDITOR -o {id_}-1.0.0.ipdeplug`
- Verificar: `python ipdeplug.py verificar {id_}-1.0.0.ipdeplug`

Antes de firmar, revise `[distribucion]` en `paquete/extension.toml` (modo, licencia, precio y la dirección donde se adquiere).
'''


def _agentes_nuevo(id_, nombre, plantilla):
    return f'''# Instrucciones para asistentes de IA: extensión «{nombre}» ({id_})

Este proyecto es una extensión (plugin) del geoportal: un paquete firmado `.ipdeplug`. Lea esto antes de
proponer cambios.

## Estructura
- `paquete/extension.toml`: manifiesto TOML (`id`, `nombre`, `version` X.Y.Z, `permisos`, `[distribucion]`,
  pasos `[[instalar]]`, `[[habilitar]]`, `[[deshabilitar]]`, `[[desinstalar]]`). No cambie `id`.
- `paquete/web/index.html`: la ÚNICA página. Todo en línea (CSS, JS, imágenes como data:). Bibliotecas sólo
  desde un CDN con CORS (cdnjs.cloudflare.com, cdn.jsdelivr.net, unpkg.com) y con versión exacta.
- Fuera de `paquete/` va lo de desarrollo (este archivo, pruebas, notas): no se firma.

## Entorno de ejecución
- La página corre en un iframe `sandbox="allow-scripts"`: sin localStorage, sin cookies, sin ventanas
  emergentes, sin descargas directas, sin acceso al DOM del geoportal. Sólo `postMessage` con `parent`.
- Debe funcionar en tema claro y oscuro (`prefers-color-scheme`) y en anchos de 320 px en adelante.

## Puente con el geoportal (ya está en web/index.html como `ipde`)
| Llamada | Permiso en extension.toml | Resultado |
|---|---|---|
| `ipde.ir(lon, lat, zoom)` | `mapa.ir` | centra el mapa; sin respuesta |
| `await ipde.capas()` | `capas.leer` | `[{{id, titulo, grupo, geometria, enMapa, elementos}}]` |
| `await ipde.datos(id)` | `capas.leer` | FeatureCollection en WGS 84 (lon, lat) |
| `await ipde.agregarCapa(titulo, fc)` | `capas.agregar` | `{{id, elementos}}`; máx. 100 000 elementos, en grados |
| `await ipde.descargar(nombre, texto, tipoMime)` | `descargas` | guarda un archivo de texto; máx. 50 MB |
| `ipde.ampliar(true/false)` | — | agranda o reduce el marco |

Si falta el permiso o algo falla, la promesa se rechaza con el mensaje de `ipde.error`. Pida sólo los permisos
que use. Las capas que sólo se sirven como imagen (WMS) no tienen datos.

## Reglas
- Escape todo texto que venga de las capas antes de insertarlo como HTML (nunca innerHTML con datos crudos).
- No envíe datos de las capas a servidores externos sin declararlo en la descripción.
- No invente mensajes del puente: la interfaz ignora los que no están en la tabla.
- No toque `paquete/META/` (la firma). Tras cualquier cambio hay que volver a empaquetar y subir `version`.
- NUNCA lea, pida ni copie la clave privada del editor (`publisher_private.pem`).

## Órdenes
- Probar: `python ipdeplug.py probar .`  (banco de pruebas en el navegador; respeta los permisos)
- Validar: `python ipdeplug.py validar .`
- Empaquetar: `python ipdeplug.py empaquetar . --editor CARPETA_DEL_EDITOR -o {id_}-VERSION.ipdeplug` (lo corre la persona)
'''


_VSCODE = '''{
  "recommendations": [
    "ms-python.python",
    "tamasfe.even-better-toml",
    "dbaeumer.vscode-eslint",
    "esbenp.prettier-vscode",
    "anthropic.claude-code"
  ]
}
'''

_GITIGNORE = '''# no subir nunca la clave del editor ni los paquetes generados
*.pem
editor_*/
*.ipdeplug
paquete/META/
__pycache__/
'''


# ---------- banco de pruebas: la página en el mismo marco aislado, con un geoportal simulado ----------

_BANCO = r'''<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Banco de pruebas · __NOMBRE__</title>
<style>
:root{color-scheme:light dark;--b:#d0d7de;--t:#1f2328;--m:#59636e;--bg:#f6f8fa;--c:#fff}
@media (prefers-color-scheme:dark){:root{--b:#3d444d;--t:#e6edf3;--m:#9198a1;--bg:#010409;--c:#0d1117}}
body{font:13px/1.45 system-ui,sans-serif;margin:0;padding:16px;color:var(--t);background:var(--bg)}
h1{font-size:16px;margin:0 0 4px}.m{color:var(--m)}
.g{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:16px;margin-top:12px}
@media (max-width:800px){.g{grid-template-columns:1fr}}
iframe{width:100%;height:520px;border:1px solid var(--b);border-radius:8px;background:#fff}
#log{background:var(--c);border:1px solid var(--b);border-radius:8px;padding:8px;height:504px;overflow:auto;font:12px/1.4 ui-monospace,Consolas,monospace}
#log div{border-bottom:1px solid var(--b);padding:3px 0;white-space:pre-wrap;word-break:break-word}.no{color:#cf222e}.si{color:#1a7f37}
code{font-family:ui-monospace,Consolas,monospace}
</style></head><body>
<h1>Banco de pruebas · __NOMBRE__ __VERSION__</h1>
<div class="m">La página corre en un marco aislado como en el geoportal. Este banco contesta a sus mensajes con dos capas de ejemplo y aplica los permisos del manifiesto: <code>__PERMISOS__</code>. No hace falta firmar para probar; para instalarla en la plataforma, sí.</div>
<div class="g"><iframe sandbox="allow-scripts" referrerpolicy="no-referrer" title="Extensión"></iframe><div><strong>Mensajes</strong><div id="log" role="log"></div></div></div>
<script>
const PAGINA = __PAGINA__, PERMISOS = new Set(['mapa.ir', ...__PERMISOS__]);
const CAPAS = {
  puntos: {id: 'puntos', titulo: 'Puntos de ejemplo', grupo: 'Ejemplo', geometria: 'Point', fc: {type: 'FeatureCollection', features: [
    {type: 'Feature', properties: {nombre: 'A'}, geometry: {type: 'Point', coordinates: [-79.52, 8.98]}},
    {type: 'Feature', properties: {nombre: 'B'}, geometry: {type: 'Point', coordinates: [-80.43, 8.42]}}]}},
  poligono: {id: 'poligono', titulo: 'Polígono de ejemplo', grupo: 'Ejemplo', geometria: 'Polygon', fc: {type: 'FeatureCollection', features: [
    {type: 'Feature', properties: {nombre: 'Zona'}, geometry: {type: 'Polygon', coordinates: [[[-80, 8], [-79.5, 8], [-79.5, 8.5], [-80, 8.5], [-80, 8]]]}}]}}
};
const fr = document.querySelector('iframe'), log = document.getElementById('log');
const anotar = (t, c) => { const d = document.createElement('div'); d.className = c || ''; d.textContent = new Date().toLocaleTimeString() + '  ' + t; log.prepend(d); };
addEventListener('message', e => {
  if (e.source !== fr.contentWindow) return;
  const d = e.data; if (!d || typeof d.tipo !== 'string') return;
  const responder = m => fr.contentWindow.postMessage(Object.assign({pedido: d.pedido}, m), '*');
  const negar = k => { anotar(d.tipo + ' → NEGADO: falta el permiso «' + k + '» en extension.toml', 'no'); responder({tipo: 'ipde.error', error: 'la extensión no declara el permiso «' + k + '»'}); };
  const corto = o => { const s = JSON.stringify(o); return s.length > 300 ? s.slice(0, 300) + '…' : s; };
  anotar('← ' + corto(d));
  if (d.tipo === 'ipde.ir') { const ok = Math.abs(+d.lon) <= 180 && Math.abs(+d.lat) <= 85; anotar(ok ? 'mapa centrado en ' + d.lat + ', ' + d.lon : 'ipde.ir ignorado: coordenadas fuera de rango', ok ? 'si' : 'no'); }
  else if (d.tipo === 'ipde.tamano') anotar('la extensión pide ' + (d.grande ? 'ampliarse' : 'reducirse'), 'si');
  else if (d.tipo === 'ipde.capas?') { if (!PERMISOS.has('capas.leer')) return negar('capas.leer'); responder({tipo: 'ipde.capas', capas: Object.values(CAPAS).map(c => ({id: c.id, titulo: c.titulo, grupo: c.grupo, geometria: c.geometria, enMapa: true, elementos: c.fc.features.length}))}); }
  else if (d.tipo === 'ipde.datos?') { if (!PERMISOS.has('capas.leer')) return negar('capas.leer'); const c = CAPAS[d.id]; responder(c ? {tipo: 'ipde.datos', id: d.id, fc: c.fc} : {tipo: 'ipde.error', error: 'no hay ninguna capa con ese id'}); }
  else if (d.tipo === 'ipde.capa') { if (!PERMISOS.has('capas.agregar')) return negar('capas.agregar'); const fc = d.fc; if (!fc || !Array.isArray(fc.features)) return responder({tipo: 'ipde.error', error: 'la capa debe ser un FeatureCollection de hasta 100 000 elementos'}); anotar('capa «' + d.titulo + '» añadida: ' + fc.features.length + ' elementos', 'si'); responder({tipo: 'ipde.capa.ok', id: 'local_1', elementos: fc.features.length}); }
  else if (d.tipo === 'ipde.descargar') { if (!PERMISOS.has('descargas')) return negar('descargas'); const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([String(d.texto)], {type: d.tipoMime || 'application/octet-stream'})); a.download = d.nombre || 'archivo'; a.click(); anotar('descargado «' + d.nombre + '»', 'si'); responder({tipo: 'ipde.descargar.ok'}); }
  else anotar('mensaje desconocido: el geoportal lo ignoraría', 'no');
});
fr.srcdoc = PAGINA;
</script></body></html>
'''


# ---------- órdenes ----------

def o_crear(a):
    if not ID_VALIDO.match(a.id):
        raise Error('el id sólo admite letras, números, - y _')
    dest = pathlib.Path(a.carpeta or a.id)
    if dest.exists() and any(dest.iterdir()):
        raise Error(f'{dest} ya existe y no está vacía')
    nombre = a.nombre or a.id.replace('_', ' ').replace('-', ' ').capitalize()
    paq = dest / PAQUETE
    (paq / 'web').mkdir(parents=True, exist_ok=True)
    (dest / '.vscode').mkdir(exist_ok=True)
    escribir = lambda ruta, texto: ruta.write_text(texto, encoding='utf-8', newline='\n')
    escribir(paq / MANIFIESTO, _manifiesto_nuevo(a.id, nombre.replace('"', "'"), a.editor, a.plantilla))
    escribir(paq / 'web' / 'index.html', _pagina_nueva(nombre, a.plantilla))
    escribir(dest / 'LEEME.md', _leeme_nuevo(a.id, nombre))
    escribir(dest / 'AGENTS.md', _agentes_nuevo(a.id, nombre, a.plantilla))
    escribir(dest / 'CLAUDE.md', '@AGENTS.md\n')
    escribir(dest / '.vscode' / 'extensions.json', _VSCODE)
    escribir(dest / '.gitignore', _GITIGNORE)
    print(f'Creado el proyecto {dest}{os.sep} (plantilla «{a.plantilla}»)\n  0. Ábralo en VS Code: code {dest}\n  1. Edite paquete/web/index.html y paquete/extension.toml (sobre todo [distribucion]).\n  2. python ipdeplug.py probar {dest}\n  3. python ipdeplug.py empaquetar {dest} --editor SU_CARPETA_DE_EDITOR')


def o_validar(a):
    a.carpeta = carpeta_paquete(a.carpeta)
    m = leer_manifiesto(a.carpeta)
    err, av = revisar_manifiesto(m, a.carpeta)
    for x in av:
        print('  aviso:', x)
    if err:
        raise Error('extension.toml tiene errores:\n  - ' + '\n  - '.join(err))
    d = m['distribucion']
    print(f'VÁLIDA  {m["id"]} {m["version"]} · permisos: {", ".join(m.get("permisos", [])) or "sólo mapa.ir"}\n  distribución: {d["modo"]} ({MODOS[d["modo"]]}) · licencia {d["licencia"]} · {d.get("precio", "gratuita")}' + (f' · {d["url"]}' if d.get('url') else ''))


def o_probar(a):
    carpeta = carpeta_paquete(a.carpeta)
    m = leer_manifiesto(carpeta)
    pag = next((p for p in m.get('habilitar', []) if p.get('accion') == 'copiar'), None)
    if not pag or not (carpeta / pag['desde'] / 'index.html').is_file():
        raise Error('la extensión no tiene página: falta [[habilitar]] copiar con desde/index.html')
    pagina = (carpeta / pag['desde'] / 'index.html').read_text(encoding='utf-8')
    permisos = [k for k in m.get('permisos', []) if k in PERMISOS]
    j = lambda o: json.dumps(o, ensure_ascii=False).replace('</', '<\\/')
    t = (_BANCO.replace('__NOMBRE__', html.escape(m.get('nombre', m['id']))).replace('__VERSION__', html.escape(m.get('version', '')))
         .replace('__PERMISOS__', j(permisos)).replace('__PAGINA__', j(pagina)))
    salida = pathlib.Path(a.salida) if a.salida else pathlib.Path(tempfile.gettempdir()) / f'banco_{m["id"]}.html'
    salida.write_text(t, encoding='utf-8')
    print(f'Banco de pruebas: {salida}')
    if not a.no_abrir:
        webbrowser.open(salida.resolve().as_uri())


def o_solicitar(a):
    if not ID_VALIDO.match(a.id):
        raise Error('el id de editor sólo admite letras, números, - y _')
    dest = pathlib.Path(a.salida or f'editor_{a.id}')
    if (dest / 'publisher_private.pem').exists():
        raise Error(f'{dest} ya tiene una clave: no se sobrescribe (si la perdió, cree otra carpeta y pida un certificado nuevo)')
    dest.mkdir(parents=True, exist_ok=True)
    clave = nueva_clave()
    pem = dest / 'publisher_private.pem'
    pem.write_bytes(clave_pem(clave))
    try:
        os.chmod(pem, 0o600)
    except OSError:
        pass
    s = {'formato': 'ipde-solicitud-editor-1', 'publisher_id': a.id, 'name': a.nombre, 'pubkey': publica_b64(clave), 'fecha': hoy(),
         'contacto': a.correo or '', 'sitio': a.sitio or ''}
    s['prueba'] = firmar_bytes(clave, carga_util_solicitud(s))
    (dest / 'solicitud.json').write_text(json.dumps(s, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(f'''Listo, en {dest}{os.sep}:
  publisher_private.pem   SU CLAVE PRIVADA. No la envíe a nadie, no la suba a un repositorio; haga una copia de seguridad.
  solicitud.json          envíela al administrador de la plataforma. Lleva sólo su clave pública.
Cuando la aprueben, le devolverán publisher.cert.json: guárdelo en esta misma carpeta.''')


def o_emitir(a):
    s = json.loads(pathlib.Path(a.solicitud).read_text(encoding='utf-8'))
    for k in ('publisher_id', 'name', 'pubkey', 'fecha', 'prueba'):
        if not isinstance(s.get(k), str) or not s[k].strip():
            raise Error(f'solicitud incompleta: falta «{k}»')
    if not ID_VALIDO.match(s['publisher_id']):
        raise Error('publisher_id inválido')
    if '\n' in s['name']:
        raise Error('el nombre no puede tener saltos de línea')
    if not verifica(s['pubkey'], carga_util_solicitud(s), s['prueba']):
        raise Error('la solicitud no está firmada con la clave que trae: no se emite')
    raiz = leer_clave(pathlib.Path(a.raiz) / 'root_private.pem')
    if publica_b64(raiz) != raiz_publica(a.raiz_publica):
        raise Error('esa clave raíz no es la de esta plataforma (no coincide con raiz_publica.txt)')
    registro = pathlib.Path(a.registro) if a.registro else None
    if registro and (registro / f'{s["publisher_id"]}.cert.json').exists():
        previo = json.loads((registro / f'{s["publisher_id"]}.cert.json').read_text(encoding='utf-8'))
        if previo.get('pubkey') != s['pubkey'] and not a.reemplazar:
            raise Error(f'ya hay un editor «{s["publisher_id"]}» con otra clave: use otro id o --reemplazar si es la misma organización que perdió su clave')
    ini = datetime.date.today()
    try:
        fin = ini.replace(year=ini.year + a.anios) - datetime.timedelta(days=1)
    except ValueError:   # 29 de febrero
        fin = ini.replace(year=ini.year + a.anios, day=28)
    cert = {'publisher_id': s['publisher_id'], 'name': s['name'], 'pubkey': s['pubkey'], 'issued': ini.isoformat(), 'expires': fin.isoformat()}
    cert['root_sig'] = firmar_bytes(raiz, carga_util_cert(cert))
    texto = json.dumps(cert, indent=2, ensure_ascii=False) + '\n'
    dest = pathlib.Path(a.salida or '.')
    dest.mkdir(parents=True, exist_ok=True)
    (dest / 'publisher.cert.json').write_text(texto, encoding='utf-8')
    if registro:
        registro.mkdir(parents=True, exist_ok=True)
        (registro / f'{s["publisher_id"]}.cert.json').write_text(texto, encoding='utf-8')
    print(f'Certificado de «{s["name"]}» ({s["publisher_id"]}) válido del {cert["issued"]} al {cert["expires"]}: {dest / "publisher.cert.json"}'
          + (f'\n  copia pública en {registro}' if registro else '') + '\nEnvíeselo al editor; no contiene nada secreto.')


def o_empaquetar(a):
    carpeta = carpeta_paquete(a.carpeta)
    clave, cert = cargar_editor(a.editor)
    m, archivos, av = firmar_carpeta(carpeta, clave, cert)
    for x in av:
        print('  aviso:', x)
    salida = pathlib.Path(a.salida or f'{m["id"]}-{m["version"]}.ipdeplug')
    empaquetar_carpeta(carpeta, m['id'], salida)
    tam = salida.stat().st_size
    if tam > LIMITE_MB * 1024 * 1024:
        print(f'  aviso: el paquete pesa {tam / 1048576:.1f} MB; el geoportal acepta hasta {LIMITE_MB} MB descomprimido')
    print(f'FIRMADO  {salida}  ({m["id"]} {m["version"]}, {len(archivos)} archivos, editor {cert["name"]}, {tam / 1024:.0f} KB)\n  sha256 {sha256(salida)}')


def o_verificar(a):
    m, cert, n = verificar(a.ruta, raiz_publica(a.raiz_publica))
    d = m.get('distribucion') or {}
    print(f'VERIFICADO\n  id       : {m["id"]}\n  versión  : {m["version"]}\n  editor   : {cert["name"]} ({cert["publisher_id"]})\n  vigencia : {cert["issued"]} → {cert["expires"]}\n  archivos : {n}'
          + (f'\n  permisos : {", ".join(m.get("permisos", []))}' if m.get('permisos') else '')
          + (f'\n  distrib. : {d.get("modo", "—")} · {d.get("licencia", "—")} · {d.get("precio", "gratuita")}' + (f' · {d["url"]}' if d.get('url') else '') if d else ''))


def o_ficha(a):
    m, cert, n = verificar(a.paquete, raiz_publica(a.raiz_publica))
    d = m.get('distribucion') or {}
    if d.get('modo') != 'catalogo':
        print(f'  aviso: [distribucion] modo = "{d.get("modo")}": sólo las de modo «catalogo» se anuncian en el catálogo')
    f = {'id': m['id'], 'nombre': m.get('nombre', m['id']), 'version': m['version'], 'descripcion': m.get('descripcion', ''),
         'editor': cert['name'], 'editor_id': cert['publisher_id'], 'licencia': d.get('licencia', ''), 'precio': d.get('precio', 'gratuita'),
         'url': d.get('url', ''), 'permisos': m.get('permisos', []), 'sha256': sha256(a.paquete)}
    if d.get('soporte'):
        f['soporte'] = d['soporte']
    if a.archivo:
        f['archivo'] = a.archivo
    texto = json.dumps(f, indent=1, ensure_ascii=False)
    if a.salida:
        pathlib.Path(a.salida).write_text(texto + '\n', encoding='utf-8')
        print(f'Ficha: {a.salida}')
    else:
        print(texto)


def main(argv=None):
    ap = argparse.ArgumentParser(prog='ipdeplug', description='SDK de extensiones (.ipdeplug) de la plataforma · ' + VERSION_SDK)
    sub = ap.add_subparsers(dest='orden', required=True)
    p = sub.add_parser('crear', help='crea la carpeta de una extensión nueva a partir de una plantilla')
    p.add_argument('id'); p.add_argument('--plantilla', choices=['pagina', 'capas'], default='pagina'); p.add_argument('--nombre'); p.add_argument('--editor'); p.add_argument('--carpeta')
    p.set_defaults(f=o_crear)
    p = sub.add_parser('validar', help='revisa extension.toml (también la distribución) sin firmar')
    p.add_argument('carpeta'); p.set_defaults(f=o_validar)
    p = sub.add_parser('probar', help='abre la página de la extensión en un banco de pruebas que simula el geoportal')
    p.add_argument('carpeta'); p.add_argument('-o', '--salida'); p.add_argument('--no-abrir', action='store_true'); p.set_defaults(f=o_probar)
    p = sub.add_parser('editor-solicitar', help='crea su clave de editor y la solicitud de certificado')
    p.add_argument('--id', required=True); p.add_argument('--nombre', required=True); p.add_argument('--correo'); p.add_argument('--sitio'); p.add_argument('-o', '--salida')
    p.set_defaults(f=o_solicitar)
    p = sub.add_parser('editor-emitir', help='(autoridad de la plataforma) firma el certificado de un editor con la clave raíz')
    p.add_argument('solicitud'); p.add_argument('--raiz', required=True, help='carpeta con root_private.pem'); p.add_argument('--raiz-publica')
    p.add_argument('--anios', type=int, default=2); p.add_argument('--registro', help='carpeta donde guardar la copia pública (p. ej. consola/firma/editores)')
    p.add_argument('--reemplazar', action='store_true'); p.add_argument('-o', '--salida'); p.set_defaults(f=o_emitir)
    p = sub.add_parser('empaquetar', help='firma la carpeta con su certificado y crea el .ipdeplug')
    p.add_argument('carpeta'); p.add_argument('--editor', required=True, help='carpeta con publisher_private.pem y publisher.cert.json'); p.add_argument('-o', '--salida')
    p.set_defaults(f=o_empaquetar)
    p = sub.add_parser('verificar', help='verifica un .ipdeplug o una carpeta firmada como lo hace la plataforma')
    p.add_argument('ruta'); p.add_argument('--raiz-publica'); p.set_defaults(f=o_verificar)
    p = sub.add_parser('ficha', help='genera la entrada del catálogo de extensiones a partir de un paquete verificado')
    p.add_argument('paquete'); p.add_argument('--archivo', help='nombre del .ipdeplug si la plataforma lo aloja (sólo gratuitas)'); p.add_argument('--raiz-publica'); p.add_argument('-o', '--salida')
    p.set_defaults(f=o_ficha)
    a = ap.parse_args(argv)
    for flujo in (sys.stdout, sys.stderr):
        try:
            flujo.reconfigure(encoding='utf-8', errors='replace')
        except (AttributeError, ValueError):
            pass
    try:
        a.f(a)
    except Error as e:
        print(str(e), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
